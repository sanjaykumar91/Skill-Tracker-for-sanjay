package com.examly.springapp.exception;

public class GlobalExceptionHandler {

}
