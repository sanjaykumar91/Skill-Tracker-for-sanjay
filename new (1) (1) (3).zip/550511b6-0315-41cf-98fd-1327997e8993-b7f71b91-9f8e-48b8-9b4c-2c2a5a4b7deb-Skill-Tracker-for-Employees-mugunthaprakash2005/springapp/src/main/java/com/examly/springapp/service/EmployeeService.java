package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// import javax.persistence.Id;

import com.examly.springapp.model.Employee;
import com.examly.springapp.repository.EmployeeRepository;

@Service
public class EmployeeService {
    @Autowired
    EmployeeRepository employeeRepository;
    
    public Employee createEmployee(Employee employee){
        return  employeeRepository.save(employee);
    }

    public void deleteEmployee(long id) {
       
        employeeRepository.deleteById(id);
        
    }

    public Employee updateEmployee(long id, Employee newEmployee) {
      return employeeRepository.findById(id).map(existing -> {
        existing.setName(newEmployee.getName());
        existing.setEmail(newEmployee.getEmail());
        existing.setDepartment(newEmployee.getDepartment());
        return employeeRepository.save(existing);
      }).orElseThrow(()-> new RuntimeException("Employee not found"));
    }

   

    public List<Employee> getAllEmployees() {
      return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(long id) {
        return employeeRepository.findById(id);
    }

   
}
