package com.examly.springapp.controller;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Employee;
import com.examly.springapp.service.EmployeeService;

@CrossOrigin(origins = {
        "*"// If you run frontend locally
})
@RestController

public class EmployeeController {
    @Autowired
    EmployeeService employeeService;


    @PostMapping("/api/employees")
    public ResponseEntity<Employee>createEmployee(@RequestBody Employee employee){
        Employee createdEmployee =employeeService.createEmployee(employee);
        return ResponseEntity.ok(createdEmployee);
    }

    @GetMapping("/api/employees")
    public List<Employee> getAllEmployees(){
        return  employeeService.getAllEmployees();
    }

    @GetMapping("/api/employees/{id}")
    public ResponseEntity<?> getEmployeeById (@PathVariable long id){
    Optional<Employee> emp= employeeService.getEmployeeById(id);
        if (emp.isPresent()) {
            return ResponseEntity.ok(emp.get());
            
        }
        else{
            Map<String,String> error= new HashMap<>();
            error.put("message", "404 Not Found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @DeleteMapping("/api/employees/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable long id){
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
        
    }

    @PutMapping("/api/employees/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable long id, @RequestBody Employee employee){
        Employee updated = employeeService.updateEmployee(id,employee);
        return ResponseEntity.ok(updated);
    }


}
