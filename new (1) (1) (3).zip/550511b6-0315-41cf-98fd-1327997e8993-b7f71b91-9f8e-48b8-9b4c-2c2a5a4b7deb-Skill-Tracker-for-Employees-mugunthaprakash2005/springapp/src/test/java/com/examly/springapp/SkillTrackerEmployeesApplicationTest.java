package com.examly.springapp;

import com.examly.springapp.controller.EmployeeController;
import com.examly.springapp.model.Employee;
import com.examly.springapp.service.EmployeeService;
import com.examly.springapp.repository.EmployeeRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.*;

@SpringBootTest
class SkillTrackerEmployeesApplicationTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @MockBean
    private EmployeeService controllerService;

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    private static String asJson(Object obj) throws Exception {
        return new ObjectMapper().writeValueAsString(obj);
    }

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    // -------- Service Tests --------

    @Test
    void testGetAllEmployeesReturnsList() {
        List<Employee> mockList = List.of(new Employee("Alice", "alice@test.com", "HR"));
        when(employeeRepository.findAll()).thenReturn(mockList);
        List<Employee> result = employeeService.getAllEmployees();
        assertEquals(1, result.size());
        assertEquals("Alice", result.get(0).getName());
    }

    @Test
    void testCreateEmployeeReturnsSavedEmployee() {
        Employee emp = new Employee("Bob", "bob@test.com", "IT");
        when(employeeRepository.save(emp)).thenReturn(emp);
        Employee result = employeeService.createEmployee(emp);
        assertEquals("Bob", result.getName());
    }

    @Test
    void testUpdateEmployeeWorksCorrectly() {
        Employee oldEmp = new Employee("Chris", "chris@test.com", "Ops");
        Employee newEmp = new Employee("Chris2", "chris2@test.com", "Ops");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(oldEmp));
        when(employeeRepository.save(any(Employee.class))).thenReturn(newEmp);
        Employee result = employeeService.updateEmployee(1L, newEmp);
        assertEquals("Chris2", result.getName());
    }

    @Test
    void testDeleteEmployeeExecutes() {
        doNothing().when(employeeRepository).deleteById(1L);
        employeeService.deleteEmployee(1L);
        verify(employeeRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetEmployeeByIdReturnsCorrectValue() {
        Employee emp = new Employee("Dan", "dan@test.com", "Finance");
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(emp));
        Optional<Employee> result = employeeService.getEmployeeById(1L);
        assertTrue(result.isPresent());
        assertEquals("Dan", result.get().getName());
    }

    // -------- Controller Tests --------

    @Test
    void testGetAllEmployeesAPI() throws Exception {
        List<Employee> list = List.of(new Employee("Eva", "eva@test.com", "Admin"));
        when(controllerService.getAllEmployees()).thenReturn(list);

        mockMvc.perform(get("/api/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Eva"));
    }

    @Test
    void testGetEmployeeByIdAPI() throws Exception {
        Employee emp = new Employee("Fay", "fay@test.com", "Sales");
        when(controllerService.getEmployeeById(1L)).thenReturn(Optional.of(emp));

        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("fay@test.com"));
    }

    @Test
    void testCreateEmployeeAPI() throws Exception {
        Employee emp = new Employee("George", "george@test.com", "Support");
        when(controllerService.createEmployee(any(Employee.class))).thenReturn(emp);

        mockMvc.perform(post("/api/employees")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJson(emp)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("George"));
    }

    @Test
    void testDeleteEmployeeAPI() throws Exception {
        doNothing().when(controllerService).deleteEmployee(1L);

        mockMvc.perform(delete("/api/employees/1"))
                .andExpect(status().isNoContent());
    }
}
