import React from 'react';

function Home() {
  return (
    <div>
      <h2>Welcome to the Employee Management System</h2>
      <p>Use the navigation to manage employees.</p>
      </div>
  );
}

export default Home;