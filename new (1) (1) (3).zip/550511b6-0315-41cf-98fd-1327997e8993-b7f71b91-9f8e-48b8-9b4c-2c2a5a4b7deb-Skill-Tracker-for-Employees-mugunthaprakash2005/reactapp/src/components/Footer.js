import React from 'react';

function Footer() {
      return (
            <footer style={{
                  marginTop: '2rem',
                  padding: '1rem',
                  background: '#eee',
                  textAlign: 'center'
            }}>
                  Employee Manager © 2025
                  </footer>
      );
}

export default Footer;